/*
 *  Copyright (c) 2016 Lukasz Pawlowski wallingsoft@live.com
 *  All rights reserved.
 *  MIT License
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the ""Software""), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *
 *  The above copyright notice and this permission notice shall be included in
 *  all copies or substantial portions of the Software.
 *
 *  THE SOFTWARE IS PROVIDED *AS IS*, WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *  THE SOFTWARE.
 */
var powerbi;
(function (powerbi) {
    var visuals;
    (function (visuals) {
        var ImgViewerVisual1455487926945;
        (function (ImgViewerVisual1455487926945) {
            var ImgViewerVisual = (function () {
                function ImgViewerVisual() {
                    this.GUID = (Math.random() * 100000000000000000000).toString();
                    this.imgElementGUID = "img_" + this.GUID;
                    this.containerGUID = "container_" + this.GUID;
                    this.imgSrcUrl = "http://mainecoon33.free.fr/images-de-bebes-animaux/img/images/images-bebes-animaux%20(12).JPG";
                    this.imgElementString = "<img width=\"{0}\" height=\"{1}\" src=\"{2}\"></img>";
                    this.data = []; //empty array.
                    this.isImgLoadError = false;
                    ImgViewerVisual.instances.push(this);
                }
                ImgViewerVisual.prototype.init = function (options) {
                    // debugger;
                    this.element = options.element;
                    this.viewport = options.viewport;
                    this.hostServices = options.host;
                    this.hasSelection = false;
                };
                ImgViewerVisual.AllowUrlAlways = function (inUrl) {
                };
                ImgViewerVisual.prototype.destroy = function () {
                    var curGUID = this.GUID;
                    // find the iframeVisual that generated the user action
                    var newArray = new Array();
                    for (var v = 0; v < ImgViewerVisual.instances.length; v++) {
                        var curInstance = ImgViewerVisual.instances[v];
                        if (curInstance.GUID !== curGUID) {
                            newArray.push(curInstance);
                        }
                    }
                    ImgViewerVisual.instances = newArray;
                };
                /** Notifies the IVisual to clear any selection. */
                ImgViewerVisual.prototype.onClearSelection = function () {
                    this.selected = [];
                    this.draw();
                };
                /** Notifies the IVisual to select the specified object. */
                ImgViewerVisual.prototype.onSelectObject = function (object) {
                    //todo does this do anything?
                    this.draw();
                };
                ImgViewerVisual.prototype.update = function (options) {
                    this.viewport = options.viewport;
                    this.updateData(options.dataViews);
                    this.draw();
                };
                ImgViewerVisual.prototype.makeUrlObj = function (inUrl) {
                    var curUrl = {
                        url: inUrl,
                        rootUrl: inUrl,
                        isWebUrl: true,
                        isWebUrlHttps: true
                    };
                    return curUrl;
                };
                ImgViewerVisual.prototype.draw = function () {
                    if (!this.self) {
                        this.self = d3.select(this.element.get(0));
                    }
                    var width = this.viewport.width;
                    var height = this.viewport.height;
                    var urlObj = null;
                    var isURLToLoad = false;
                    var urlToLoad = "";
                    // build the load url
                    if (this.data.length !== 0) {
                        urlObj = this.makeUrlObj(this.data[0].url);
                        urlToLoad = urlObj.url;
                        isURLToLoad = true;
                    }
                    else {
                        return;
                    }
                    // provide a div to host the content.
                    if (!this.container) {
                        var curContainer = d3.select(this.element.get(0)).append("div");
                        curContainer.attr("id", this.containerGUID).attr("overflow", "auto");
                        this.container = curContainer;
                    }
                    // ensure if the url changed, the user is warned.
                    // default to warn the user
                    var isURLUpdated = false;
                    this.isAllowedByUser = true;
                    //remove warning box
                    if (this.warningBox) {
                        this.warningBox.remove();
                        this.warningBox = null;
                        this.container.attr("style", "overflow: hidden;" + "height: 100%;" + "width: 100%;");
                    }
                    //draw the iframe 
                    if (!this.imgElement) {
                        this.isImgLoadError = false;
                        var curImg = this.container.append("img");
                        curImg.attr("id", this.imgElementGUID).attr("class", "img-viewer-image").attr("iframeVisualBinding", this.GUID);
                        try {
                            curImg.attr("src", urlObj.url);
                        }
                        catch (err) {
                            console.error(err);
                        }
                        this.imgElement = curImg;
                    }
                    //set dimensions
                    this.imgElement.attr("width", "100%").attr("height", "100%");
                    //update if the url changed
                    var curURL = this.imgElement.attr("src");
                    if (!curURL || (curURL && (curURL !== urlObj.url))) {
                        this.isImgLoadError = false;
                        this.imgElement.attr("src", urlObj.url);
                    }
                };
                ImgViewerVisual.prototype.showIframeError = function (msg, url, line) {
                    this.imgElement.remove();
                    //this.container.
                };
                ImgViewerVisual.prototype.handleAllowClick = function (d, i) {
                    // now in the context of the button that was clicked
                    var allowForGUID = d3.event.srcElement.getAttribute("iframevisualbinding");
                    var allowedURLByUser = d3.event.srcElement.getAttribute("iframeVisualCurrentUrl");
                    for (var v = 0; v < ImgViewerVisual.instances.length; v++) {
                        var curInstance = ImgViewerVisual.instances[v];
                        if (curInstance.GUID === allowForGUID) {
                            curInstance.isAllowedByUser = true;
                            curInstance.allowedURLByUser = allowedURLByUser;
                            curInstance.draw();
                            break;
                        }
                    }
                };
                ImgViewerVisual.prototype.handleAllowAlwaysClick = function (d, i) {
                    // now in the context of the button that was clicked
                    var allowForGUID = d3.event.srcElement.getAttribute("iframevisualbinding");
                    var rootUrl = d3.event.srcElement.getAttribute("iframeVisualRootUrl");
                    var allowedURLByUser = d3.event.srcElement.getAttribute("iframeVisualCurrentUrl");
                    ImgViewerVisual.AllowUrlAlways(rootUrl);
                    for (var v = 0; v < ImgViewerVisual.instances.length; v++) {
                        var curInstance = ImgViewerVisual.instances[v];
                        if (curInstance.GUID === allowForGUID) {
                            curInstance.isAllowedByUser = true;
                            curInstance.allowedURLByUser = allowedURLByUser;
                            curInstance.draw();
                            break;
                        }
                    }
                };
                ImgViewerVisual.prototype.handleIFrameLoad = function (d, i) {
                    var visualGUID = d3.event.srcElement.getAttribute("iframevisualbinding");
                };
                ImgViewerVisual.prototype.handleIFrameError = function (d, i) {
                    var visualGUID = d3.event.srcElement.getAttribute("iframevisualbinding");
                    for (var v = 0; v < ImgViewerVisual.instances.length; v++) {
                        var curInstance = ImgViewerVisual.instances[v];
                        if (curInstance.GUID === visualGUID) {
                            curInstance.isImgLoadError = true;
                            curInstance.draw();
                            break;
                        }
                    }
                };
                ImgViewerVisual.prototype.updateData = function (inDataViews) {
                    //clear data
                    this.data = [];
                    var curDV = null;
                    //var cat = null;
                    // convert from dataView to array of IFrameVisualData
                    if (inDataViews && inDataViews.length > 0) {
                        if (inDataViews[0].table) {
                            //curDV = inDataViews[0];
                            curDV = inDataViews[0].table;
                        }
                    }
                    if (!curDV || !curDV.columns || !curDV.rows) {
                        this.data = [];
                        return; //TODO do something better
                    }
                    var numColumns = 0;
                    if (curDV.columns) {
                        numColumns = curDV.columns.length;
                    }
                    var numRows = 0;
                    if (curDV.rows) {
                        numRows = curDV.rows.length;
                    }
                    if (!numColumns || numColumns < 1)
                        return;
                    for (var n = 0; n < numRows; n++) {
                        var curDatum = {
                            label: "",
                            url: curDV.rows[n][0],
                            color: "",
                            selected: false,
                            //identity: childIdentity,  //ref treemap
                            //identity: inDataViews[0].table.identity[n],
                            //identity: SelectionId.createWithId(cat.identity[n]), //.getSelector(),
                            identity: null,
                            tooltipInfo: null,
                            highlightedTooltipInfo: null,
                        };
                        this.data.push(curDatum);
                    }
                    // returns the identity for the Nth rowCount
                    // options.dataViews[0].table.identity[n]
                };
                // how to validate these are correct?
                ImgViewerVisual.instances = new Array();
                ImgViewerVisual.capabilities = {
                    dataRoles: [
                        {
                            name: 'Values',
                            kind: powerbi.VisualDataRoleKind.Grouping,
                            displayName: 'URL',
                            description: 'Provide the URL to an image'
                        }
                    ],
                    dataViewMappings: [{
                        conditions: [{ 'Values': { max: 1 } }],
                        categorical: {
                            categories: {
                                for: { in: 'Values' },
                                dataReductionAlgorithm: { window: {} }
                            },
                            includeEmptyGroups: false,
                        }
                    }],
                    //supportsHighlight: true,
                    sorting: {
                        default: {},
                    },
                    suppressDefaultTitle: true,
                };
                return ImgViewerVisual;
            })();
            ImgViewerVisual1455487926945.ImgViewerVisual = ImgViewerVisual;
        })(ImgViewerVisual1455487926945 = visuals.ImgViewerVisual1455487926945 || (visuals.ImgViewerVisual1455487926945 = {}));
    })(visuals = powerbi.visuals || (powerbi.visuals = {}));
})(powerbi || (powerbi = {}));
/*
module powerbi.visuals.plugins {
    export var IFrameChart: IVisualPlugin = {
        name: 'IFrameChart',
        //class: 'IFrameVisual',
        capabilities: IFrameVisual.capabilities,
        create: () => new IFrameVisual()
    };
}
*/
var powerbi;
(function (powerbi) {
    var visuals;
    (function (visuals) {
        var plugins;
        (function (plugins) {
            plugins.ImgViewerVisual1455487926945 = {
                name: 'ImgViewerVisual1455487926945',
                class: 'ImgViewerVisual1455487926945',
                capabilities: powerbi.visuals.ImgViewerVisual1455487926945.ImgViewerVisual.capabilities,
                custom: true,
                create: function () { return new powerbi.visuals.ImgViewerVisual1455487926945.ImgViewerVisual(); }
            };
        })(plugins = visuals.plugins || (visuals.plugins = {}));
    })(visuals = powerbi.visuals || (powerbi.visuals = {}));
})(powerbi || (powerbi = {}));
